//
//  WinningViewController.swift
//  HighLow
//
//  Created by Jake Adebayo on 9/19/23.
//

import UIKit

class WinningViewController: UIViewController {

    var winningScore: Int = 0 // You can use this property to display the player's score

    @IBOutlet weak var lblMessage: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Customize the winning message and display the player's score if needed
        lblMessage.text = "You Won! Score: \(winningScore)"
    }
    
    @IBAction func playAgainButtonClicked(_ sender: UIButton) {
    }
    
}



    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


